- 👋 Hi, I’m @aswinichalla12
- 👀 I’m interested in coding
- 🌱 I’m currently pursuing my bachelor's degree in computer science and engineering...
- 😄 Pronouns: she/her
  

<!---
aswinichalla12/aswinichalla12 is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
